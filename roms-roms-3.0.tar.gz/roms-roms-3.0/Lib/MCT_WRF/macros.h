#define ASSERT(a) CALL Assert(a,__LINE__,__FILE__)
