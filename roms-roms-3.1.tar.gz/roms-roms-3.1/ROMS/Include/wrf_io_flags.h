/*
** svn $Id$
*******************************************************************************
** Copyright (c) 2002-2008 The ROMS/TOMS Group                               **
**   Licensed under a MIT/X style license                                    **
**   See License_ROMS.txt                                                    **
*******************************************************************************
*/
      integer, parameter  :: WRF_FILE_NOT_OPENED                  = 100
      integer, parameter  :: WRF_FILE_OPENED_NOT_COMMITTED        = 101
      integer, parameter  :: WRF_FILE_OPENED_AND_COMMITTED        = 102
      integer, parameter  :: WRF_FILE_OPENED_FOR_READ             = 103
      integer, parameter  :: WRF_REAL                             = 104
      integer, parameter  :: WRF_DOUBLE                           = 105
      integer, parameter  :: WRF_INTEGER                          = 106
      integer, parameter  :: WRF_COMPLEX                          = 107
      integer, parameter  :: WRF_DOUBLE_COMPLEX                   = 108
      integer, parameter  :: WRF_LOGICAL                          = 109
      integer, parameter  :: WRF_MCT_IO_ERROR                     = 200
